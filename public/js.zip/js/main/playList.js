let songs = [
    {
      name: "6 Shots - NEFFEX",
      artist: "NEFFEX",
      img: "img1",
      audio: "music1"
    },
    {
      name: "No Mercy - TrackTribe",
      artist: "TrackTribe",
      img: "img2",
      audio: "music2"
    },
    {
      name: "Slipping Away - Dyalla",
      artist: "Dyalla",
      img: "img3",
      audio: "music3"
    },
    {
      name: "Desert Planet - Quincas",
      artist: "Quincas",
      img: "img4",
      audio: "music4"
    }
  ]